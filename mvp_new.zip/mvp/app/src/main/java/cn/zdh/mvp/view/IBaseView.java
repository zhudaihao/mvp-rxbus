package cn.zdh.mvp.view;

public interface IBaseView {
}
