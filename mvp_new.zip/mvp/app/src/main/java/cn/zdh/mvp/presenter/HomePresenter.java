package cn.zdh.mvp.presenter;


import java.util.List;

import cn.zdh.mvp.bean.HomeBean;
import cn.zdh.mvp.model.HomeModel;
import cn.zdh.mvp.model.IHomeModel;
import cn.zdh.mvp.view.IBaseView;
import cn.zdh.mvp.view.IHomeView;

public class HomePresenter<T extends IBaseView> extends BasePresenter<T> {
    //持有model
    private IHomeModel iHomeModel = new HomeModel();

    @Override
    public void fetch() {

        iHomeModel.loadData(new IHomeModel.IHomeData() {
            @Override
            public void getData(List<HomeBean> list) {

            IHomeView iHomeView= (IHomeView) iBaseView.get();

            iHomeView.getGirlData(list);


            }
        });

    }


}
