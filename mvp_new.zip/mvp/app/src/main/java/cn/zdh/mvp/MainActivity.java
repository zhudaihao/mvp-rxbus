package cn.zdh.mvp;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;

import cn.zdh.isolation_network_processor.callback.ICallback;
import cn.zdh.isolation_network_processor.subjectProxy.HttpHelper;
import cn.zdh.mvp.adapter.GirlAdapter;
import cn.zdh.mvp.bean.GirlBean;
import cn.zdh.mvp.presenter.GirlPresenter;
import cn.zdh.mvp.view.BaseActivity;
import cn.zdh.mvp.view.IGirlView;


/**
 * mvp
 */
public class MainActivity extends BaseActivity<GirlPresenter<IGirlView>, IGirlView> implements IGirlView {
    private ListView listView;
    private GirlAdapter girlAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.lv);

        //表示层 实现对应逻辑
        presenter.fetch();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                startActivity(new Intent(MainActivity.this, HomeActivity.class));


                setNet();
            }
        });

    }



    /**
     * 网络
     */
    private void setNet() {
        //测试隔离层代码
        String url = "https://mbd.baidu.com/";
        final HashMap params = new HashMap();
        params.put("context", "%7B%22nid%22%3A%22news_9665426971658518505%22%7D");
        params.put("n_type", 0);
        params.put("p_from", 1);
        HttpHelper.obtain().post(url, params, new ICallback() {
            @Override
            public void onNetStart() {

            }

            @Override
            public void onNetEnd() {

            }

            @Override
            public void onNetSuccess(String result) {

                Toast.makeText(MainActivity.this, ""+result, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNetFailure(String error) {

            }
        });
    }

    /**
     * 创建对应表示层
     */
    @Override
    protected GirlPresenter<IGirlView> createPresenter() {
        return new GirlPresenter();
    }


    /**
     * activity需要获取哪个结果，就实现对应接口
     *
     * @param girlBeans
     */
    @Override
    public void getGirlData(List<GirlBean> girlBeans) {
        girlAdapter = new GirlAdapter(girlBeans, this);
        listView.setAdapter(girlAdapter);
    }


}
