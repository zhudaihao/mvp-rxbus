package cn.zdh.mvp.bean;

public class HomeBean {
    private String uri;

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public HomeBean(String uri) {
        this.uri = uri;
    }
}
